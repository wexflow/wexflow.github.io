import platform

print("Hello Wexflow!")
print("Python version " + platform.python_version())