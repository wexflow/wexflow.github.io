UPDATE data SET `Description` = 'Hello World Description 3! updated' WHERE `Id` = 3;
UPDATE data SET `Description` = 'Hello World Description 4! updated' WHERE `Id` = 4;